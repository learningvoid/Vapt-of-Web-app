I collected information about possible vulnerabilities in PPT.Thank you
